﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    interface ICoin
    {
        double Weight
        {
            get;
            set;
        }
        int Size
        {
            get;
            set;
        }
        string Name
        {
            get;
            set;
        }
        double Val
        {
            get;
            set;
        }
        
       // void setCoins();

    }
}

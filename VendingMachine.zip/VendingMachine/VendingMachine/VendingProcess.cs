﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    public class VendingProcess 
    {
        List<double> weightlist = new List<double>();
        List<int> sizelist = new List<int>();
        List<double> coinlist = new List<double>();
        
        public int checkCoins(List<double> coins, double price)
        {
            int status = 0, i = 0;
            if (coins.Count == 0)
            {
                return -1;
            }
             while (price >= coins[i] && i<coins.Count)
            {
                price -= coins[i];
                i++;
                if (price <= 0)
                {
                    status = 1;
                    break;
                }
            }
            return status;
        }

        

        public void insertCoins()
        {
            Console.WriteLine("Print the number of coins you will insert");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Insert the coins");
            for (int i = 0; i < n; i++)
            {
                weightlist.Add(Convert.ToDouble(Console.ReadLine()));
                sizelist.Add(Convert.ToInt32(Console.ReadLine()));
                string validval = validCoins(weightlist[i] * sizelist[i], Coin.validcoins);
                if (validval != null)
                {
                    coinlist.Add(Coin.coinsvalue[validval]);

                }
            }
            if (coinlist.Count < 1)
            {
                Console.WriteLine("Insert Coin");
            }
        }

        

        public void itemPurchase()
        {
            Console.WriteLine("Enter the item");
            string pur_item = Console.ReadLine();
            double amount = Item.items[pur_item];
            int status = checkCoins(coinlist, amount);
            if (status == 1)
                Console.WriteLine("Thank you !");
            else
                Console.WriteLine("Not sufficient amount");
        }

       
        string validCoins(double val, Dictionary<double, string> validcoins)
        {
            string value = null;
            foreach (KeyValuePair<double, string> ele in validcoins)
            {
                if (val == ele.Key)
                {
                    value = ele.Value;
                    break;

                }

            }

            return value;
        }
    }
}

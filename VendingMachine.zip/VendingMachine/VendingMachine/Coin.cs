﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    
    class Coin : ICoin
    {
        public static Dictionary<double, string> validcoins = new Dictionary<double, string>();
        public static Dictionary<string, double> coinsvalue = new Dictionary<string, double>();
        double wt { get; set; }
        int size { get; set; }
        string name { get; set; }
        double val { get; set; }
        double ICoin.Weight {
            get
            {
                return wt;
            }
            set
            {
                wt = value;
            }
        }
        int ICoin.Size {
            get
            {
                return size;
            }
            set
            {
               size = value;
            }
        }
        string ICoin.Name {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        double ICoin.Val {
            get
            {
                return val;
            }
            set
            {
                val = value;
            }
        }

        public static void setCoinlist()
        {
            ICoin nickels = new Coin();
            nickels.Name = "Nickels";
            nickels.Size = 5;
            nickels.Val = 0.05;
            nickels.Weight = 10;

            ICoin dimes = new Coin();
            dimes.Name = "Dimes";
            dimes.Size = 5;
            dimes.Val = 0.10;
            dimes.Weight = 11;

            ICoin quaters = new Coin();
            quaters.Name = "Quaters";
            quaters.Size = 5;
            quaters.Val = 0.25;
            quaters.Weight = 12;

            validcoins.Add(nickels.Size* nickels.Weight, nickels.Name);
            validcoins.Add(dimes.Size* dimes.Weight, dimes.Name);
            validcoins.Add(quaters.Size* quaters.Weight, quaters.Name);
            coinsvalue.Add(nickels.Name, nickels.Val);
            coinsvalue.Add(dimes.Name,dimes.Val);
            coinsvalue.Add(quaters.Name,quaters.Val);
        }
       
        
    }
}

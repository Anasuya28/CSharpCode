﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    class Item : IItem
    {
        public static Dictionary<string, double> items = new Dictionary<string, double>();
        string name { get; set; }
        double price { get; set; }
        string IItem.Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        double IItem.Price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }
        public static void setiemlist()
        {
            IItem cola = new Item();
            cola.Name = "Cola";
            cola.Price = 1.00;

            IItem chips = new Item();
            chips.Name = "Chips";
            chips.Price = 0.50;

            IItem candy = new Item();
            candy.Name = "Candy";
            candy.Price = 0.65;
            items.Add(cola.Name, cola.Price);
            items.Add(chips.Name, chips.Price);
            items.Add(candy.Name, candy.Price);



        }
    }
}

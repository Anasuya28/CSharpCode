﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace VendingMachineTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var expectedoutput = 1;
            List<double> test = new List<double>();
            test.Add(0.25);
            test.Add(0.25);
            VendingMachine.VendingProcess obj1 = new VendingMachine.VendingProcess();
            var actualoutput = obj1.checkCoins(test, 0.5);
            Assert.AreEqual(expectedoutput, actualoutput);
        }
      
        



    }
}
